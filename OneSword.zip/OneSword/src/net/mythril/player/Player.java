package net.mythril.player;

import net.mythril.entity.Entity;

public class Player extends Entity
{

	public Player(int x, int y, int width, int height) 
	{
		super(x, y, width, height);
	}

}
